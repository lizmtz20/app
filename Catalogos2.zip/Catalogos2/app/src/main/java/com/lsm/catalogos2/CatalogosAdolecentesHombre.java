package com.lsm.catalogos2;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class CatalogosAdolecentesHombre extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_catologos_adolescenteshombre);

    }
}
