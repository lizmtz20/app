package com.lsm.catalogos2;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.android.volley.toolbox.StringRequest;

import java.net.URL;

public class MainActivity extends AppCompatActivity {

    EditText edtId,edtNombre_producto,edtPrecio;
    Button btnAgregar;

    CardView btnNinos,btnAdolescentes,btnAdultos;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edtId=(EditText)findViewById(R.id.edtId);
        edtNombre_producto=(EditText)findViewById(R.id.edtNombre_producto);
        edtPrecio=(EditText)findViewById(R.id.edtPrecio);
        btnAgregar=(Button)findViewById(R.id.btnAgregar);

        btnAgregar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });
        private void ejecutarServicio(String URL){
            StringRequest stringRequest= new StringRequest
        }

        btnNinos =findViewById(R.id.button1);
        btnAdolescentes =findViewById(R.id.button2);
        btnAdultos =findViewById(R.id.button3);

        btnNinos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent btnNinos = new Intent(MainActivity.this,CatalogosNinos.class);
                startActivity(btnNinos);
            }
        });

        btnAdolescentes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent btnNinos = new Intent(MainActivity.this, CatalogosAdolescentes.class);
                startActivity(btnNinos);
            }
        });

        btnAdultos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent btnNinos = new Intent(MainActivity.this,CatalogosAdultos.class);
                startActivity(btnNinos);
            }
        });

    }
}