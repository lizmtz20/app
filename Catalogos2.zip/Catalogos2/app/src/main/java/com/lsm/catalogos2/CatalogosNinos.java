package com.lsm.catalogos2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

public class CatalogosNinos extends AppCompatActivity {

    CardView btnNinos, btnNinas;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_catalogos_ninos);

        btnNinos = findViewById(R.id.button1);
        btnNinas =findViewById(R.id.button2);

        btnNinas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent btnNinas = new Intent(CatalogosNinos.this,CatalogosNinosnina.class);
                startActivity(btnNinas);
            }
        });

        btnNinos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent btnNinos = new Intent(CatalogosNinos.this,CatalogosNinosnino.class);
                startActivity(btnNinos);
            }
        });
    }
}