package com.lsm.catalogos2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class CatalogosAdolescentes extends AppCompatActivity {
    CardView btnMujer, btnHombre;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_catalogos_adolecentes);

        btnMujer = findViewById(R.id.button1);
        btnHombre =findViewById(R.id.button2);

        btnMujer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent btnMujer = new Intent(CatalogosAdolescentes.this,CatalogosAdolecentesMujer.class);
                startActivity(btnMujer);
            }
        });

        btnHombre.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent btnHombre = new Intent(CatalogosAdolescentes.this,CatalogosAdolecentesHombre.class);
                startActivity(btnHombre);
            }
        });
    }
}