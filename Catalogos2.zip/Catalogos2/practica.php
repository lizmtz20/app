<?
$conexion = mysql_connect("localhost","root","","tabla");

if($conexion){
    echo "Conexion exitosa";
}else{
    echo "Fallo la conexion";
}
?>