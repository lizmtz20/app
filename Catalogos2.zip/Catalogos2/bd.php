<?php

include('bd.php');

if($_SERVER['REQUEST_METHOD'] == 'POST'){

    $imagen = $_POST['foto'];
    $nombre = $_POST['nombre'];

   //RUTA DONDE SE GUARDARAN LAS IMAGENES 
   
   $path = "megamoda/$nombre.png";
   $actualpath = "https:localhost/catalogos2/$path";
   $sql = 'INSERT INTO ropa(id, foto, nombre)VALUES('NULL','$actualpath','$nombre')';
   if(mysql_query($conexion.$sql)){
      file_put_contents($path,base64_decode($imagen));
      echo "Se subio exitosamente";
      mysqli_close($conexion);
   }else{
    echo "Error";
   }
}
?>